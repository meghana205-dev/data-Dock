const express = require("express");
const router = express.Router();

// Temporary test GET route
router.get("/", (req, res) => {
    res.json([
        { id: 1, name: "mmmf Cutter Model A", price: 15000, description: "Test product" }
    ]);
});

module.exports = router;
