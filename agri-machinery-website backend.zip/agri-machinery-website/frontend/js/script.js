// Fetch and display products
fetch("http://localhost:5000/api/products")
  .then(res => res.json())
  .then(products => {
    const container = document.getElementById("product-list");
    products.forEach(p => {
      const card = document.createElement("div");
      card.className = "product";
      card.innerHTML = `
        <img src="${p.imageUrl}" alt="${p.name}">
        <h3>${p.name}</h3>
        <p>${p.description}</p>
        <p><b>₹${p.price}</b></p>
      `;
      container.appendChild(card);
    });
  });
